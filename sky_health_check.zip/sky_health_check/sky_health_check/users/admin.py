# users/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Department, Team, User, Session, HealthCard, Vote, Instruction

@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'department')
    list_filter = ('department',)

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('role', 'team', 'department')}),
    )
    list_display = ('id', 'username', 'email', 'role', 'team', 'department', 'is_staff')
    list_filter = ('role', 'team', 'department', 'is_staff')
    search_fields = ('username', 'email')

@admin.register(Session)
class SessionAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'date')

@admin.register(HealthCard)
class HealthCardAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')

@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'team', 'session', 'health_card', 'color', 'improving')
    list_filter = ('color', 'improving', 'session', 'team')

@admin.register(Instruction)
class InstructionAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')
