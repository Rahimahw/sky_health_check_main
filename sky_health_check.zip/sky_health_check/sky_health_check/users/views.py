from django.shortcuts import render, redirect
from django.contrib.auth.views import LoginView
from .forms import CustomUserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.shortcuts import redirect
from django.views.generic import TemplateView
from .models import Department

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  
    else:
        form = CustomUserCreationForm()
    return render(request, 'users/register.html', {'form': form})

# Login View
class CustomLoginView(LoginView):
    template_name = 'users/login.html'

@login_required
def home(request):
    return render(request, 'users/home.html')


def logout_view(request):
    logout(request)  
    return redirect('home')  


@login_required
def instructions(request):
    return render(request, 'users/instructions.html')


@login_required
def department_summaries(request):
    # Check if the user is a Senior Manager or other roles that should access this page
    if request.user.role == 'SeniorManager' or request.user.role == 'DepartmentLeader':
        # Get the department summaries based on your requirements
        departments = Department.objects.all()  # Modify this based on your model and data
        return render(request, 'users/department_summaries.html', {'departments': departments})
    else:
        return render(request, 'users/no_permission.html')  # Or redirect to another page