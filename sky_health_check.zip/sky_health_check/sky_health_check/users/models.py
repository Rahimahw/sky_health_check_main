from django.contrib.auth.models import AbstractUser
from django.db import models


class Department(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Team(models.Model):
    name = models.CharField(max_length=100)
    department = models.ForeignKey(Department, on_delete=models.CASCADE, related_name='teams')

    def __str__(self):
        return self.name


class User(AbstractUser):
    ROLE_CHOICES = [
        ('Engineer', 'Engineer'),
        ('TeamLeader', 'Team Leader'),
        ('DepartmentLeader', 'Department Leader'),
        ('SeniorManager', 'Senior Manager'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    team = models.ForeignKey(Team, null=True, blank=True, on_delete=models.SET_NULL, related_name='members')
    department = models.ForeignKey(Department, null=True, blank=True, on_delete=models.SET_NULL, related_name='members')

    def __str__(self):
        return self.username


class Session(models.Model):
    name = models.CharField(max_length=100)
    date = models.DateField()

    def __str__(self):
        return f"{self.name} ({self.date})"

class HealthCard(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Vote(models.Model):
    COLOR_CHOICES = [
        ('Green', 'Green'),
        ('Amber', 'Amber'),
        ('Red', 'Red'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='votes')
    session = models.ForeignKey(Session, on_delete=models.CASCADE, related_name='votes')
    team = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='votes')
    health_card = models.ForeignKey(HealthCard, on_delete=models.CASCADE, related_name='votes')
    color = models.CharField(max_length=10, choices=COLOR_CHOICES)
    improving = models.BooleanField(default=False)
    comment = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.team.name} - {self.health_card.name} ({self.color})"


class Instruction(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()

    def __str__(self):
        return self.title
